﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAnimatedGuy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.imgAvatar = New System.Windows.Forms.PictureBox()
        Me.btnNorth = New System.Windows.Forms.Button()
        Me.btnEast = New System.Windows.Forms.Button()
        Me.btnWest = New System.Windows.Forms.Button()
        Me.btnSouthEast = New System.Windows.Forms.Button()
        Me.btnSouthWest = New System.Windows.Forms.Button()
        Me.btnSouth = New System.Windows.Forms.Button()
        Me.btnNorthWest = New System.Windows.Forms.Button()
        Me.btnNorthEast = New System.Windows.Forms.Button()
        Me.AnimatedGuyTimer = New System.Windows.Forms.Timer(Me.components)
        Me.btnSlowDown = New System.Windows.Forms.Button()
        Me.btnSpeedUp = New System.Windows.Forms.Button()
        Me.btnStopAvatar = New System.Windows.Forms.Button()
        CType(Me.imgAvatar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imgAvatar
        '
        Me.imgAvatar.Location = New System.Drawing.Point(268, 106)
        Me.imgAvatar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.imgAvatar.Name = "imgAvatar"
        Me.imgAvatar.Size = New System.Drawing.Size(56, 72)
        Me.imgAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imgAvatar.TabIndex = 0
        Me.imgAvatar.TabStop = False
        '
        'btnNorth
        '
        Me.btnNorth.Location = New System.Drawing.Point(551, 206)
        Me.btnNorth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNorth.Name = "btnNorth"
        Me.btnNorth.Size = New System.Drawing.Size(35, 27)
        Me.btnNorth.TabIndex = 1
        Me.btnNorth.Text = "N"
        Me.btnNorth.UseVisualStyleBackColor = True
        '
        'btnEast
        '
        Me.btnEast.Location = New System.Drawing.Point(591, 239)
        Me.btnEast.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnEast.Name = "btnEast"
        Me.btnEast.Size = New System.Drawing.Size(35, 27)
        Me.btnEast.TabIndex = 2
        Me.btnEast.Text = "E"
        Me.btnEast.UseVisualStyleBackColor = True
        '
        'btnWest
        '
        Me.btnWest.Location = New System.Drawing.Point(511, 239)
        Me.btnWest.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnWest.Name = "btnWest"
        Me.btnWest.Size = New System.Drawing.Size(35, 27)
        Me.btnWest.TabIndex = 3
        Me.btnWest.Text = "W"
        Me.btnWest.UseVisualStyleBackColor = True
        '
        'btnSouthEast
        '
        Me.btnSouthEast.Location = New System.Drawing.Point(591, 272)
        Me.btnSouthEast.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSouthEast.Name = "btnSouthEast"
        Me.btnSouthEast.Size = New System.Drawing.Size(45, 27)
        Me.btnSouthEast.TabIndex = 4
        Me.btnSouthEast.Text = "SE"
        Me.btnSouthEast.UseVisualStyleBackColor = True
        '
        'btnSouthWest
        '
        Me.btnSouthWest.Location = New System.Drawing.Point(501, 272)
        Me.btnSouthWest.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSouthWest.Name = "btnSouthWest"
        Me.btnSouthWest.Size = New System.Drawing.Size(43, 27)
        Me.btnSouthWest.TabIndex = 5
        Me.btnSouthWest.Text = "SW"
        Me.btnSouthWest.UseVisualStyleBackColor = True
        '
        'btnSouth
        '
        Me.btnSouth.Location = New System.Drawing.Point(551, 272)
        Me.btnSouth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSouth.Name = "btnSouth"
        Me.btnSouth.Size = New System.Drawing.Size(35, 27)
        Me.btnSouth.TabIndex = 6
        Me.btnSouth.Text = "S"
        Me.btnSouth.UseVisualStyleBackColor = True
        '
        'btnNorthWest
        '
        Me.btnNorthWest.Location = New System.Drawing.Point(501, 206)
        Me.btnNorthWest.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNorthWest.Name = "btnNorthWest"
        Me.btnNorthWest.Size = New System.Drawing.Size(43, 27)
        Me.btnNorthWest.TabIndex = 7
        Me.btnNorthWest.Text = "NW"
        Me.btnNorthWest.UseVisualStyleBackColor = True
        '
        'btnNorthEast
        '
        Me.btnNorthEast.Location = New System.Drawing.Point(591, 206)
        Me.btnNorthEast.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNorthEast.Name = "btnNorthEast"
        Me.btnNorthEast.Size = New System.Drawing.Size(45, 27)
        Me.btnNorthEast.TabIndex = 8
        Me.btnNorthEast.Text = "NE"
        Me.btnNorthEast.UseVisualStyleBackColor = True
        '
        'AnimatedGuyTimer
        '
        '
        'btnSlowDown
        '
        Me.btnSlowDown.Location = New System.Drawing.Point(564, 151)
        Me.btnSlowDown.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSlowDown.Name = "btnSlowDown"
        Me.btnSlowDown.Size = New System.Drawing.Size(35, 27)
        Me.btnSlowDown.TabIndex = 9
        Me.btnSlowDown.Text = "\/"
        Me.btnSlowDown.UseVisualStyleBackColor = True
        '
        'btnSpeedUp
        '
        Me.btnSpeedUp.Location = New System.Drawing.Point(523, 151)
        Me.btnSpeedUp.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSpeedUp.Name = "btnSpeedUp"
        Me.btnSpeedUp.Size = New System.Drawing.Size(35, 27)
        Me.btnSpeedUp.TabIndex = 10
        Me.btnSpeedUp.Text = "/\"
        Me.btnSpeedUp.UseVisualStyleBackColor = True
        '
        'btnStopAvatar
        '
        Me.btnStopAvatar.Location = New System.Drawing.Point(523, 106)
        Me.btnStopAvatar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnStopAvatar.Name = "btnStopAvatar"
        Me.btnStopAvatar.Size = New System.Drawing.Size(76, 27)
        Me.btnStopAvatar.TabIndex = 11
        Me.btnStopAvatar.Text = "Stop"
        Me.btnStopAvatar.UseVisualStyleBackColor = True
        '
        'frmAnimatedGuy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 352)
        Me.Controls.Add(Me.btnStopAvatar)
        Me.Controls.Add(Me.btnSpeedUp)
        Me.Controls.Add(Me.btnSlowDown)
        Me.Controls.Add(Me.btnNorthEast)
        Me.Controls.Add(Me.btnNorthWest)
        Me.Controls.Add(Me.btnSouth)
        Me.Controls.Add(Me.btnSouthWest)
        Me.Controls.Add(Me.btnSouthEast)
        Me.Controls.Add(Me.btnWest)
        Me.Controls.Add(Me.btnEast)
        Me.Controls.Add(Me.btnNorth)
        Me.Controls.Add(Me.imgAvatar)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmAnimatedGuy"
        Me.Text = "Animated Guy"
        CType(Me.imgAvatar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents imgAvatar As System.Windows.Forms.PictureBox
    Friend WithEvents btnNorth As System.Windows.Forms.Button
    Friend WithEvents btnEast As System.Windows.Forms.Button
    Friend WithEvents btnWest As System.Windows.Forms.Button
    Friend WithEvents btnSouthEast As System.Windows.Forms.Button
    Friend WithEvents btnSouthWest As System.Windows.Forms.Button
    Friend WithEvents btnSouth As System.Windows.Forms.Button
    Friend WithEvents btnNorthWest As System.Windows.Forms.Button
    Friend WithEvents btnNorthEast As System.Windows.Forms.Button
    Friend WithEvents AnimatedGuyTimer As System.Windows.Forms.Timer
    Friend WithEvents btnSlowDown As System.Windows.Forms.Button
    Friend WithEvents btnSpeedUp As System.Windows.Forms.Button
    Friend WithEvents btnStopAvatar As System.Windows.Forms.Button

End Class
