﻿' Purpose : Develop a class in VB with
' Animation. Show how to move the logic into the one class.
' This is what encapsulataion is all about.
' Date : Feb 27th 2015

Public Class frmAnimatedGuy

    ' Animated avatar
    Public joe As AnimatedGuy


    Private Sub frmAnimatedGuy_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        ' Create a new instance of AnimatedGuy
        joe = New AnimatedGuy("running_",
                              "e",
                               Me, Me.imgAvatar)

        Me.AnimatedGuyTimer.Start()

    End Sub

    Private Sub AnimatedGuyTimer_Tick(sender As System.Object, e As System.EventArgs) Handles AnimatedGuyTimer.Tick
        joe.allez()
    End Sub

    
    Private Sub btnNorth_Click(sender As System.Object, e As System.EventArgs) Handles btnNorth.Click
        ' Make joe go North
        joe.goNorth()
    End Sub

    Private Sub btnEast_Click(sender As System.Object, e As System.EventArgs) Handles btnEast.Click
        ' Make joe go East
        joe.goEast()
    End Sub

    Private Sub btnSouth_Click(sender As System.Object, e As System.EventArgs) Handles btnSouth.Click
        ' Make joe go South
        joe.goSouth()
    End Sub

    Private Sub btnWest_Click(sender As System.Object, e As System.EventArgs) Handles btnWest.Click
        ' Make joe go West
        joe.goWest()

    End Sub

    Private Sub btnNorthEast_Click(sender As System.Object, e As System.EventArgs) Handles btnNorthEast.Click
        ' Make joe go North West
        joe.goNorthEast()
    End Sub

    Private Sub btnSouthEast_Click(sender As System.Object, e As System.EventArgs) Handles btnSouthEast.Click
        ' Make joe go South East
        joe.goSouthEast()
    End Sub

    Private Sub btnSouthWest_Click(sender As System.Object, e As System.EventArgs) Handles btnSouthWest.Click
        ' Make joe Go South West
        joe.goSouthWest()

    End Sub

    Private Sub btnNorthWest_Click(sender As System.Object, e As System.EventArgs) Handles btnNorthWest.Click
        ' Make joe go North West
        joe.goNorthWest()

    End Sub

    Private Sub btnSpeedUp_Click(sender As System.Object, e As System.EventArgs) Handles btnSpeedUp.Click
        joe.speedUp()
    End Sub

    Private Sub btnSlowDown_Click(sender As System.Object, e As System.EventArgs) Handles btnSlowDown.Click
        joe.slowDown()
    End Sub

   
    Private Sub btnStopAvatar_Click(sender As System.Object, e As System.EventArgs) Handles btnStopAvatar.Click
        joe.stopWalking()
    End Sub
End Class

Public Class AnimatedGuy
    ' Directional constants
    Const NORTH_DX = 0
    Const NORTH_DY = -1
    Const SOUTH_DX = 0
    Const SOUTH_DY = 1
    Const EAST_DX = 1
    Const EAST_DY = 0
    Const WEST_DX = -1
    Const WEST_DY = 0
    Const NORTHWEST_DX = -0.7
    Const NORTHWEST_DY = -0.7
    Const SOUTHWEST_DX = -0.7
    Const SOUTHWEST_DY = 0.7
    Const NORTHEAST_DX = 0.7
    Const NORTHEAST_DY = -0.7
    Const SOUTHEAST_DX = 0.7
    Const SOUTHEAST_DY = 0.7

    ' Attributes
    Private _baseId As String
    Private _direction As String
    Private _pose As Integer
    Private _dx As Integer
    Private _dy As Integer
    Private _form As frmAnimatedGuy
    Private _img As PictureBox
    Private _speed As Integer = 3
    Private _stopState As Boolean = False

    'Constructor
    Public Sub New(baseId, direction, form, img)
        _direction = direction
        _baseId = baseId
        _pose = 0
        _dx = 1
        _dy = 0
        _form = form
        _img = img
        _speed = 3

    End Sub
    ' Property Methods
    Public Property Speed
        Get
            Return _speed
        End Get
        Set(value)
            If (value < 1) Then
                _speed = 1
            ElseIf (value > 10) Then
                _speed = 10
            Else
                _speed = value
            End If
        End Set
    End Property
    Public Property StopState
        Get
            Return _stopState
        End Get
        Set(value)
            _stopState = value
        End Set
    End Property
    Public Property Img
        Get
            Return _img

        End Get
        Set(value)
            _img = value

        End Set
    End Property
    Public Property Form
        Get
            Return _form

        End Get
        Set(value)
            _form = value

        End Set
    End Property
    Public Property BaseId
        Get
            Return _baseId

        End Get
        Set(value)
            _baseId = value

        End Set
    End Property
    Public Property Direction
        Get
            Return _direction

        End Get
        Set(value)
            _direction = value
            StopState = False
            Select Case _direction
                Case "n"
                    _dx = NORTH_DX
                    _dy = NORTH_DY
                Case "s"
                    _dx = SOUTH_DX
                    _dy = SOUTH_DY
                Case "e"
                    _dx = EAST_DX
                    _dy = EAST_DY
                Case "w"
                    _dx = WEST_DX
                    _dy = WEST_DY
                Case "ne"
                    _dx = NORTHEAST_DX
                    _dy = NORTHEAST_DY
                Case "nw"
                    _dx = NORTHWEST_DX
                    _dy = NORTHWEST_DY
                Case "se"
                    _dx = SOUTHEAST_DX
                    _dy = SOUTHEAST_DY
                Case "sw"
                    _dx = SOUTHWEST_DX
                    _dy = SOUTHWEST_DY
            End Select

        End Set
    End Property
    Public Property Pose
        Get
            Return _pose

        End Get
        Set(value)
            If (value > 7) Then
                _pose = 0
            Else
                _pose = value
            End If
        End Set
    End Property
    Public Property Dx
        Get
            Return _dx

        End Get
        Set(value)
            _dx = value

        End Set
    End Property
    Public Property Dy
        Get
            Return _dy

        End Get
        Set(value)
            _dy = value

        End Set
    End Property

    Public Sub checkBounds()
        ' Wrap
        If _img.Top < 0 Then
            _img.Top = _form.Height()
        ElseIf _img.Top > _form.Height() Then
            _img.Top = 0
        ElseIf _img.Left > _form.Width() Then
            _img.Left = 0
        ElseIf _img.Top < 0 Then
            _img.Top = _form.Height()
        End If
    End Sub

    Public Sub nextPose()
        ' Increment the pose
        Pose += 1
        ' Change the image
        Dim id = BaseId + Direction + "000" + Pose.ToString()
        _img.Image =
            My.Resources.ResourceManager.GetObject(id)
    End Sub

    Public Sub Marchez()
        ' Add the dx and the dy directional increments
        _img.Left += Dx
        _img.Top += Dy

    End Sub

    Public Sub allez()
        If Not (StopState) Then
            ' Get the next pose
            nextPose()
            ' move the avatar
            Marchez()
            ' Check to see if avatar is within bounds
            checkBounds()
        End If
    End Sub

    Public Sub speedUp()
        Speed += 1
        _dx = _dx * Speed
        _dy = _dy * Speed
    End Sub

    Public Sub slowDown()
        Speed -= 1
        _dx = _dx * Speed
        _dy = _dy * Speed
    End Sub

    Public Sub stopWalking()
        _dx = 0
        _dy = 0
        StopState = True
    End Sub

    Public Sub goNorth()
        Direction = "n"
    End Sub

    Public Sub goSouth()
        Direction = "s"
    End Sub


    Public Sub goEast()
        Direction = "e"
    End Sub


    Public Sub goWest()
        Direction = "w"
    End Sub


    Public Sub goNorthEast()
        Direction = "ne"
    End Sub


    Public Sub goNorthWest()
        Direction = "nw"
    End Sub


    Public Sub goSouthEast()
        Direction = "se"
    End Sub


    Public Sub goSouthWest()
        Direction = "sw"
    End Sub
End Class

